﻿namespace ATMDispensacion.Models
{
    public class DispensacionModel
    {
        public string DispensarDinero(string modo, int monto)
        {
            switch (modo)
            {
                case "eficiente":
                    return DispensarEficiente(monto);
                case "200y1000":
                    return Dispensar200y1000(monto);
                case "100y500":
                    return Dispensar100y500(monto);
                default:
                    return "Modo de dispensación no válido.";
            }
        }

        private string DispensarEficiente(int monto)
        {
            // Lógica para dispensar de manera eficiente
            int[] denominaciones = { 1000, 500, 200, 100 };
            int[] resultado = CalcularPapeletas(monto, denominaciones);

            return FormatearResultado(resultado, denominaciones);
        }

        private string Dispensar200y1000(int monto)
        {
            // Lógica para dispensar solo de 200 y 1000
            int[] denominaciones = { 1000, 200 };
            int[] resultado = CalcularPapeletas(monto, denominaciones);

            return FormatearResultado(resultado, denominaciones);
        }

        private string Dispensar100y500(int monto)
        {
            // Lógica para dispensar solo de 100 y 500
            int[] denominaciones = { 500, 100 };
            int[] resultado = CalcularPapeletas(monto, denominaciones);

            return FormatearResultado(resultado, denominaciones);
        }

        private int[] CalcularPapeletas(int monto, int[] denominaciones)
        {
            int[] resultado = new int[denominaciones.Length];
            for (int i = 0; i < denominaciones.Length; i++)
            {
                resultado[i] = monto / denominaciones[i];
                monto %= denominaciones[i];
            }
            return resultado;
        }

        private string FormatearResultado(int[] resultado, int[] denominaciones)
        {
            string res = "Dispensado: ";
            for (int i = 0; i < resultado.Length; i++)
            {
                if (resultado[i] > 0)
                {
                    res += $"{resultado[i]} papeleta(s) de {denominaciones[i]}, ";
                }
            }
            return res.TrimEnd(',', ' ');
        }
    }
}
