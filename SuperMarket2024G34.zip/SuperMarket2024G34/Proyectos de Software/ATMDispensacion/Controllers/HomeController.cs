using Microsoft.AspNetCore.Mvc;
using ATMDispensacion.Models;

namespace ATMDispensacion.Controllers
{
    public class HomeController : Controller
    {
        private readonly DispensacionModel _dispensacionModel = new DispensacionModel();

        public IActionResult Index()
        {
            ViewBag.ModoDispensacion = HttpContext.Session.GetString("ModoDispensacion") ?? "eficiente";
            return View();
        }

        [HttpPost]
        public IActionResult ConfigurarModo(string modoDispensacion)
        {
            HttpContext.Session.SetString("ModoDispensacion", modoDispensacion);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Retirar(int montoRetiro)
        {
            string modoDispensacion = HttpContext.Session.GetString("ModoDispensacion") ?? "eficiente";
            string dispensacion = _dispensacionModel.DispensarDinero(modoDispensacion, montoRetiro);
            ViewBag.Dispensacion = dispensacion;
            ViewBag.ModoDispensacion = modoDispensacion;
            return View("Index");
        }
    }
}

