﻿using Application.Services;
using Application.Viewmodels;
using Microsoft.AspNetCore.Mvc;

namespace SuperMarket2024G34.Controllers
{
    public class MarketController : Controller
    {
        private ProductService productService;
        public MarketController()
        {
            productService = new();
        }
        public IActionResult Index(string? message = null, string? messageType = null)
        {
            ViewBag.Message = message;
            ViewBag.MessageType = messageType;
            return View(productService.GetAll());
        }

        public IActionResult CreateProduct()
        {
            return View();
        }

        [HttpPost] //Annotation
        public IActionResult CreateProduct(CreateProductViewModel vm)
        {
            try
            {
                productService.Add(vm);
                return RedirectToRoute(new { controller = "Market", action = "Index",message = "Product created successfully",messageType= "alert-success" });//dynamic
            }
            catch (Exception)
            {
                return RedirectToRoute(new { controller = "Market", action = "Index", message = "Product creation failed", messageType = "alert-danger" });//dynamic
            }
           
        }
    }
}
