﻿namespace Application.Enums
{
    public enum ProductType
    {
        FRUIT = 1,
        VEGETABLE,
        DAIRY_PRODUCT
    }
}
