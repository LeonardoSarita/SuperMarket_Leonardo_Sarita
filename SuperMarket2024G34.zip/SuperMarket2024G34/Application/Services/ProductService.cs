﻿using Application.Enums;
using Application.Repositories;
using Application.Viewmodels;

namespace Application.Services
{
    public class ProductService
    { 
        public void Add(CreateProductViewModel vm)
        {           
            switch(vm.ProductType)
            {
                case (int)ProductType.FRUIT:
                    ProductRepository.Instance.Products.Fruits.Add(new ProductViewModel
                    {
                        Name = vm.Name,
                        Description = vm.Description,
                        Price = vm.Price
                    });
                    break;
                case (int)ProductType.VEGETABLE:
                    ProductRepository.Instance.Products.Vegetables.Add(new ProductViewModel
                    {
                        Name = vm.Name,
                        Description = vm.Description,
                        Price = vm.Price
                    });
                    break;
                case (int)ProductType.DAIRY_PRODUCT:
                    ProductRepository.Instance.Products.DairyProducts.Add(new ProductViewModel
                    {
                        Name = vm.Name,
                        Description = vm.Description,
                        Price = vm.Price
                    });
                    break;
            }
        }

        public ProductListViewModel GetAll()
        {
            return ProductRepository.Instance.Products;
        }
    }
}
